import { useEffect, useState } from "react";
import TodoForm from "./components/TodoForm";
import TodoList from "./components/TodoList";
import api from "./services/todoService";
import "./App.css";

function App() {
  const [todos, setTodos] = useState([]);

  const load = async () => { const res = await api.getAll(); setTodos(res.data); };
  useEffect(() => { load(); }, []);

  const add = async (todo) => { await api.create(todo); load(); };
  const remove = async (id) => { await api.remove(id); load(); };
  const toggle = async (todo) => { await api.update(todo.id, { ...todo, completed: !todo.completed }); load(); };
  const update = async (id, data) => { await api.update(id, data); load(); };

  return (
    <div className="app">
      <h1>✅ Smart Todo Manager</h1>
      <TodoForm onAdd={add} />
      <TodoList todos={todos} onDelete={remove} onToggle={toggle} onUpdate={update} />
    </div>
  );
}

export default App;
