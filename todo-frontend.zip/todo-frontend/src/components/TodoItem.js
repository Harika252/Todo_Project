import { useState } from "react";

function TodoItem({ todo, onDelete, onToggle, onUpdate }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(todo.title);
  const [description, setDescription] = useState(todo.description);

  const save = () => {
    onUpdate(todo.id, { ...todo, title, description });
    setEditing(false);
  };

  return (
    <div className={`todo-card ${todo.completed ? "done" : ""}`}>
      {editing ? (
        <>
          <input value={title} onChange={e => setTitle(e.target.value)} />
          <input value={description} onChange={e => setDescription(e.target.value)} />
        </>
      ) : (
        <>
          <h3>{todo.title}</h3>
          <p>{todo.description}</p>
        </>
      )}
      <div className="actions">
        <button onClick={() => onToggle(todo)}>{todo.completed ? "Undo" : "Done"}</button>
        {editing ? <button onClick={save}>Save</button> : <button onClick={() => setEditing(true)}>Edit</button>}
        <button className="danger" onClick={() => onDelete(todo.id)}>Delete</button>
      </div>
    </div>
  );
}

export default TodoItem;
