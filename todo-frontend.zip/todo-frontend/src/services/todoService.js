import axios from "axios";

const API = "http://localhost:8080/api/todos";

const api = {
  getAll: () => axios.get(API),
  create: (todo) => axios.post(API, todo),
  update: (id, todo) => axios.put(`${API}/${id}`, todo),
  remove: (id) => axios.delete(`${API}/${id}`)
};

export default api;
